import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FolderOpen, 
  X, 
  Info, 
  Palette, 
  Monitor,
  Contrast,
  Leaf,
  Snowflake,
  Circle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { ContextMenuItem } from '@/types';

interface ContextMenuProps {
  isOpen: boolean;
  position: { x: number; y: number };
  items: ContextMenuItem[];
  onClose: () => void;
  onAction: (actionId: string) => void;
}

export const ContextMenu: React.FC<ContextMenuProps> = ({
  isOpen,
  position,
  items,
  onClose,
  onAction,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') onClose();
      });
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  // Adjust position to keep menu on screen
  const adjustedPosition = {
    x: Math.min(position.x, window.innerWidth - 200),
    y: Math.min(position.y, window.innerHeight - 300),
  };

  const getIcon = (iconName?: string) => {
    switch (iconName) {
      case 'open': return <FolderOpen className="h-4 w-4" />;
      case 'close': return <X className="h-4 w-4" />;
      case 'info': return <Info className="h-4 w-4" />;
      case 'theme': return <Palette className="h-4 w-4" />;
      case 'light': return <Monitor className="h-4 w-4" />;
      case 'dark': return <Monitor className="h-4 w-4" />;
      case 'high-contrast': return <Contrast className="h-4 w-4" />;
      case 'leaves': return <Leaf className="h-4 w-4" />;
      case 'snow': return <Snowflake className="h-4 w-4" />;
      case 'none': return <Circle className="h-4 w-4" />;
      default: return null;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={menuRef}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.1 }}
          style={{
            position: 'fixed',
            left: adjustedPosition.x,
            top: adjustedPosition.y,
            zIndex: 9999,
          }}
          className="min-w-[180px] bg-card/95 backdrop-blur-lg border border-border rounded-lg shadow-2xl py-1"
          role="menu"
        >
          {items.map((item, index) => (
            <React.Fragment key={item.id}>
              {item.separator && index > 0 && (
                <div className="my-1 border-t border-border" />
              )}
              <button
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors',
                  item.disabled
                    ? 'opacity-50 cursor-not-allowed'
                    : 'hover:bg-muted cursor-pointer'
                )}
                onClick={() => {
                  if (!item.disabled) {
                    onAction(item.id);
                    onClose();
                  }
                }}
                disabled={item.disabled}
                role="menuitem"
              >
                {getIcon(item.icon)}
                <span className="flex-1 text-left">{item.label}</span>
                {item.shortcut && (
                  <span className="text-xs text-muted-foreground">{item.shortcut}</span>
                )}
              </button>
            </React.Fragment>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};
