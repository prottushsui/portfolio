export { AboutContent } from './AboutContent';
export { ProjectsContent } from './ProjectsContent';
export { ResumeContent } from './ResumeContent';
export { ContactContent } from './ContactContent';
